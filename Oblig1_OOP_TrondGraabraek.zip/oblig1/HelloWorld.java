public class HelloWorld {
  public static void main(String[] args) {
    //Printer ut beskjed til kommandolinjen
    System.out.println("Hello World");
  }
}